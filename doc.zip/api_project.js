define({
  "name": "Building Management System",
  "version": "0.0.1",
  "description": "api Documentation",
  "title": "apiDoc",
  "url": "http://IP:port/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-09-13T11:59:33.369Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
