define({
    vi: {
        'Allowed values:'             : 'Giá trị chấp nhận:',
        'Compare all with predecessor': 'So sánh với tất cả phiên bản trước',
        'compare changes to:'         : 'so sánh sự thay đổi với:',
        'compared to'                 : 'so sánh với',
        'Default value:'              : 'Giá trị mặc định:',
        'Description'                 : 'Chú thích',
        'Field'                       : 'Trường dữ liệu',
        'General'                     : 'Tổng quan',
        'Generated with'              : 'Được tạo bởi',
        'Name'                        : 'Tên',
        'No response values.'         : 'Không có kết quả trả về.',
        'optional'                    : 'Tùy chọn',
        'Parameter'                   : 'Tham số',
        'Permission:'                 : 'Quyền hạn:',
        'Response'                    : 'Kết quả',
        'Send'                        : 'Gửi',
        'Send a Sample Request'       : 'Gửi một yêu cầu mẫu',
        'show up to version:'         : 'hiển thị phiên bản:',
        'Size range:'                 : 'Kích cỡ:',
        'Type'                        : 'Kiểu',
        'url'                         : 'liên kết'
    }
});
